
import socket
import json
from core.agent import AIAgent
from plugins.example_api import API_model

HOST = '127.0.0.1'
PORT = 5050

def API_model(agent):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen(1)
        print(f"[AIAgent] Listening on {HOST}:{PORT}")

        while True:
            conn, addr = server_socket.accept()
            with conn:
                data = conn.recv(4096)
                if not data:
                    continue
                try:
                    request = json.loads(data.decode())
                    user_message = request.get("message", "")
                    if not user_message:
                        response = {"error": "Пустое сообщение"}
                    else:
                        agent_response = agent.ask(user_message)
                        response = {"response": agent_response}
                except Exception as e:
                    response = {"error": str(e)}
                conn.sendall(json.dumps(response).encode())

def main():
    agent = AIAgent()
    agent.start()
    try:
        API_model(agent)
    finally:
        agent.stop()

if __name__ == "__main__":
    main()
