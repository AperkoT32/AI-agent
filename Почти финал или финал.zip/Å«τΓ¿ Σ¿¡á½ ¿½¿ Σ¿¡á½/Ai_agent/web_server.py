from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import socket
import json
import os
from typing import Optional

app = FastAPI()

HOST = '127.0.0.1'
PORT = 5050
IMAGES_DIR = os.path.join("plugins", "images")

# Убедимся, что директория для изображений существует
os.makedirs(IMAGES_DIR, exist_ok=True)

# Добавляем обслуживание статических файлов для папки gift
if os.path.exists("gift"):
    app.mount("/gift", StaticFiles(directory="gift"), name="gift")

@app.get("/")
def root():
    return FileResponse("index.html")

@app.get("/style.css")
def get_style():
    return FileResponse("style.css")

@app.get("/script.js")
def get_script():
    return FileResponse("script.js")

@app.post("/api/chat")
async def chat(
    request: Request,
    file: Optional[UploadFile] = File(None),
    message: Optional[str] = Form(None)
):
    try:
        user_message = ""
        
        # Если есть файл
        if file and file.filename:
            print(f"[DEBUG] Получен файл: {file.filename}")
            
            # Сохраняем файл
            file_path = os.path.join(IMAGES_DIR, file.filename)
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            print(f"[DEBUG] Файл сохранен: {file_path}")
            
            # Формируем сообщение с командой импорта
            if message and message.strip():
                user_message = f"!import {file.filename}\\n{message}"
            else:
                user_message = f"!import {file.filename}\\nОпишите это изображение"
            
            print(f"[DEBUG] Сформированное сообщение: {user_message}")
            
        elif message:
            # Обычный текстовый запрос
            user_message = message
            print(f"[DEBUG] Текстовое сообщение: {user_message}")
        else:
            # Проверяем, может быть это JSON запрос
            try:
                data = await request.json()
                user_message = data.get("message", "")
                print(f"[DEBUG] JSON сообщение: {user_message}")
            except:
                return JSONResponse(content={"error": "Пустое сообщение"}, status_code=400)

        if not user_message:
            return JSONResponse(content={"error": "Пустое сообщение"}, status_code=400)
        
        # Импортируем функцию санитизации
        try:
            from plugins.example_api import sanitize_input
            sanitized_message = sanitize_input(user_message)
        except ImportError:
            # Если функция недоступна, используем сообщение как есть
            sanitized_message = user_message
        
        print(f"[DEBUG] Отправляем сообщение на порт {PORT}: {sanitized_message}")

        # Отправляем запрос к Jane Assistant
        with socket.create_connection((HOST, PORT), timeout=30) as sock:
            request_data = json.dumps({"message": sanitized_message})
            sock.sendall(request_data.encode())
            
            # Получаем ответ
            response_data = sock.recv(8096)  # Увеличиваем буфер
            result = json.loads(response_data.decode())
            
        print(f"[DEBUG] Получен ответ: {result}")

        if "response" in result:
            return {"response": result["response"]}
        else:
            return JSONResponse(content={"error": result.get("error", "Агент не ответил")}, status_code=500)

    except Exception as e:
        print(f"[ERROR] Ошибка в /api/chat: {e}")
        import traceback
        traceback.print_exc()
        return JSONResponse(content={"error": str(e)}, status_code=500)