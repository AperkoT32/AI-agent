document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const fileInput = document.getElementById('file-input');
    const attachButton = document.getElementById('attach-button');
    
    let chatHistory = [];
    let currentChatId = 'chat-' + Date.now();
    let isEditingTitle = false;
    let isFileDialogOpen = false;
    
    function createNewChat() {
        // Save current chat if needed
        saveCurrentChat();
        
        // Create new chat ID
        currentChatId = 'chat-' + Date.now();
        
        // Clear messages with smooth animation
        chatMessages.style.opacity = '0';
        setTimeout(() => {
            chatMessages.innerHTML = `
                <div class="message assistant">
                    <div class="message-content">
                            <p><strong>Привет! Я Джейн — ваш ИИ-ассистент.</strong></p>
                        
                        <p>Я могу помочь вам с:</p>
                        <ul>
                            <li>💬 Ответами на вопросы и объяснениями</li>
                            <li>🖼️ Анализом изображений и документов</li>
                            <li>✍️ Написанием и редактированием текстов</li>
                            <li>💻 Программированием и техническими задачами</li>
                            <li>🌐 Переводами и языковыми вопросами</li>
                        </ul>
                        
                        <p>Просто напишите ваш вопрос или прикрепите файл для анализа! 📎</p>
                    </div>
                </div>
            `;
            chatMessages.style.opacity = '1';
        }, 150);
        

        chatHistory = [];
        

        addChatToSidebar(currentChatId, 'Новый чат');
        

        userInput.focus();
    }
    
    function addChatToSidebar(id, title) {
        const chatHistoryContainer = document.querySelector('.chat-history');
        const chatItem = document.createElement('div');
        chatItem.className = 'chat-item';
        chatItem.dataset.id = id;
        
        chatItem.innerHTML = `
            <div class="chat-item-content">
                <span class="chat-title" title="${title}">${title}</span>
                <div class="chat-actions">
                    <button class="edit-chat" title="Переименовать">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <button class="delete-chat" title="Удалить">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        
        // Add click handlers
        const chatContent = chatItem.querySelector('.chat-item-content');
        const titleSpan = chatItem.querySelector('.chat-title');
        const editButton = chatItem.querySelector('.edit-chat');
        const deleteButton = chatItem.querySelector('.delete-chat');
        
        // Click to switch chat
        chatContent.addEventListener('click', (e) => {
            if (!e.target.closest('.chat-actions') && !isEditingTitle) {
                loadChat(id);
                setActiveChatItem(chatItem);
            }
        });
        
        // Edit chat title
        editButton.addEventListener('click', (e) => {
            e.stopPropagation();
            editChatTitle(chatItem, titleSpan, id);
        });
        
        // Delete chat
        deleteButton.addEventListener('click', (e) => {
            e.stopPropagation();
            showDeleteConfirmation(id, chatItem, title);
        });
        
        chatHistoryContainer.appendChild(chatItem);
        setActiveChatItem(chatItem);
        
        // Smooth animation for new chat item
        chatItem.style.opacity = '0';
        chatItem.style.transform = 'translateX(-20px)';
        setTimeout(() => {
            chatItem.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            chatItem.style.opacity = '1';
            chatItem.style.transform = 'translateX(0)';
        }, 50);
    }
    
    function editChatTitle(chatItem, titleSpan, chatId) {
        if (isEditingTitle) return;
        
        isEditingTitle = true;
        const currentTitle = titleSpan.textContent;
        
        // Create input field
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentTitle;
        input.className = 'chat-title-input';
        input.maxLength = 50;
        
        // Replace span with input
        titleSpan.style.display = 'none';
        titleSpan.parentNode.insertBefore(input, titleSpan);
        input.focus();
        input.select();
        
        function finishEditing(save = true) {
            if (!isEditingTitle) return;
            
            isEditingTitle = false;
            const newTitle = save ? input.value.trim() || currentTitle : currentTitle;
            
            // Update title
            titleSpan.textContent = newTitle;
            titleSpan.title = newTitle;
            titleSpan.style.display = '';
            
            // Remove input
            if (input.parentNode) {
                input.parentNode.removeChild(input);
            }
            
            // Save to localStorage if title changed
            if (save && newTitle !== currentTitle) {
                saveChatTitle(chatId, newTitle);
            }
        }
        
        // Handle input events
        input.addEventListener('blur', () => finishEditing(true));
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                finishEditing(true);
            } else if (e.key === 'Escape') {
                e.preventDefault();
                finishEditing(false);
            }
        });
    }
    
    function saveChatTitle(chatId, title) {
        const chatData = localStorage.getItem(chatId);
        if (chatData) {
            try {
                const data = JSON.parse(chatData);
                data.title = title;
                localStorage.setItem(chatId, JSON.stringify(data));
            } catch (e) {
                // If old format, convert to new format
                const messages = JSON.parse(chatData);
                const newData = {
                    title: title,
                    messages: messages,
                    createdAt: Date.now()
                };
                localStorage.setItem(chatId, JSON.stringify(newData));
            }
        }
    }
    
    function showDeleteConfirmation(chatId, chatItem, title) {
        // Create confirmation modal
        const modal = document.createElement('div');
        modal.className = 'delete-modal';
        modal.innerHTML = `
            <div class="delete-modal-content">
                <h3>Удалить чат?</h3>
                <p>Вы уверены, что хотите удалить чат "${title}"?<br>Это действие нельзя отменить.</p>
                <div class="delete-modal-actions">
                    <button class="cancel-btn">Отмена</button>
                    <button class="confirm-delete-btn">Удалить</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add event listeners
        const cancelBtn = modal.querySelector('.cancel-btn');
        const confirmBtn = modal.querySelector('.confirm-delete-btn');
        
        cancelBtn.addEventListener('click', () => {
            closeModal(modal);
        });
        
        confirmBtn.addEventListener('click', () => {
            deleteChat(chatId, chatItem);
            closeModal(modal);
        });
        
        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
        
        // Close on Escape key
        const escapeHandler = (e) => {
            if (e.key === 'Escape') {
                closeModal(modal);
                document.removeEventListener('keydown', escapeHandler);
            }
        };
        document.addEventListener('keydown', escapeHandler);
        
        // Animate modal appearance
        setTimeout(() => {
            modal.classList.add('show');
        }, 10);
    }
    
    function closeModal(modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
        }, 200);
    }
    
    function setActiveChatItem(activeItem) {
        document.querySelectorAll('.chat-item').forEach(item => {
            item.classList.remove('active');
        });
        activeItem.classList.add('active');
    }
    
    function deleteChat(chatId, chatItem) {
        // Remove from localStorage
        localStorage.removeItem(chatId);
        
        // Animate removal
        chatItem.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        chatItem.style.opacity = '0';
        chatItem.style.transform = 'translateX(-20px)';
        
        setTimeout(() => {
            if (chatItem.parentNode) {
                chatItem.parentNode.removeChild(chatItem);
            }
        }, 300);
        
        // If this was the current chat, create a new one or switch to another
        if (chatId === currentChatId) {
            const remainingChats = document.querySelectorAll('.chat-item');
            if (remainingChats.length > 1) {
                // Switch to the first remaining chat
                const firstChat = remainingChats[0];
                if (firstChat !== chatItem) {
                    const firstChatId = firstChat.dataset.id;
                    loadChat(firstChatId);
                    setActiveChatItem(firstChat);
                } else if (remainingChats[1]) {
                    const secondChatId = remainingChats[1].dataset.id;
                    loadChat(secondChatId);
                    setActiveChatItem(remainingChats[1]);
                }
            } else {
                // No other chats, create a new one
                createNewChat();
            }
        }
    }
    
    function saveCurrentChat() {
        const messages = Array.from(chatMessages.children).map(msg => {
            return {
                type: msg.classList.contains('user') ? 'user' : 'assistant',
                content: msg.querySelector('.message-content').textContent
            };
        });
        
        if (messages.length > 1) { 
            let existingChatData = localStorage.getItem(currentChatId);
            let chatData = {};

            if (existingChatData) {
                try {
                    chatData = JSON.parse(existingChatData);
                } catch (e) {
                    console.error("Ошибка анализа существующих данных чата:", e);
                    chatData = {};
                }
            }

            if (!chatData.createdAt) {
                chatData.createdAt = Date.now();
            }
            
            chatData.title = getChatTitle(currentChatId);
            chatData.messages = messages;
            chatData.updatedAt = Date.now();

            localStorage.setItem(currentChatId, JSON.stringify(chatData));
        }
    }
    
    function getChatTitle(chatId) {
        const chatItem = document.querySelector(`[data-id="${chatId}"]`);
        if (chatItem) {
            const titleSpan = chatItem.querySelector('.chat-title');
            return titleSpan ? titleSpan.textContent : 'Новый чат';
        }
        return 'Новый чат';
    }
    
    function loadChat(chatId) {
        const savedChat = localStorage.getItem(chatId);
        if (savedChat) {
            try {
                const data = JSON.parse(savedChat);
                let messages;
                
                // Handle both old and new format
                if (data.messages) {
                    messages = data.messages;
                } else {
                    // Old format - array of messages
                    messages = data;
                }
                
                // Clear current messages with animation
                chatMessages.style.opacity = '0';
                setTimeout(() => {
                    chatMessages.innerHTML = '';
                    messages.forEach(msg => {
                        addMessage(msg.content, msg.type === 'user', false);
                    });
                    chatMessages.style.opacity = '1';
                    currentChatId = chatId;
                }, 150);
                
            } catch (e) {
                console.error('Error loading chat:', e);
                createNewChat();
            }
        }
    }

    function addMessage(content, isUser = false, animate = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.innerHTML = content;
        
        messageDiv.appendChild(messageContent);
        
        if (animate) {
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = 'translateY(20px)';
        }
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        if (animate) {
            setTimeout(() => {
                messageDiv.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                messageDiv.style.opacity = '1';
                messageDiv.style.transform = 'translateY(0)';
            }, 50);
        }
        
        // Add to chat history
        chatHistory.push({
            type: isUser ? 'user' : 'assistant',
            content: content
        });
        
        // Auto-update chat title based on first user message
        if (isUser && chatHistory.filter(msg => msg.type === 'user').length === 1) {
            autoUpdateChatTitle(content);
        }
    }
    
    function autoUpdateChatTitle(firstMessage) {
        const chatItem = document.querySelector(`[data-id="${currentChatId}"]`);
        if (chatItem) {
            const titleSpan = chatItem.querySelector('.chat-title');
            if (titleSpan && titleSpan.textContent === 'Новый чат') {
                // Generate title from first message (max 30 chars)
                let title = firstMessage.length > 30 
                    ? firstMessage.substring(0, 30) + '...' 
                    : firstMessage;
                
                titleSpan.textContent = title;
                titleSpan.title = title;
                saveChatTitle(currentChatId, title);
            }
        }
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message && fileInput.files.length === 0) return;
    
        // Disable input while sending
        setInputState(false);
    
        // Добавляем сообщение пользователя
        if (message) {
            addMessage(message, true);
        }
    
        // Если есть файл, показываем информацию о нем
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const fileMessage = `📎 Прикреплен файл: ${file.name}`;
            addMessage(fileMessage, true);
        }
    
        userInput.value = '';
    
        // Create typing indicator
        const typingDiv = createTypingIndicator();
        chatMessages.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    
        try {
            console.log('Отправка запроса:', message);
        
            let requestOptions = {
                method: 'POST'
            };
        
            // Если есть файл, используем FormData
            if (fileInput.files.length > 0) {
                const formData = new FormData();
                formData.append('file', fileInput.files[0]);
                formData.append('message', message || '');
            
                requestOptions.body = formData;
                // Не устанавливаем Content-Type для FormData
            } else {
                // Обычный JSON запрос
                requestOptions.headers = {
                    'Content-Type': 'application/json',
                };
                requestOptions.body = JSON.stringify({ message });
            }
        
            const response = await fetch('/api/chat', requestOptions);
        
            console.log('Получен ответ:', response);
            const data = await response.json();
            console.log('Данные ответа:', data);
        
            // Remove typing indicator
            if (typingDiv.parentNode) {
                typingDiv.style.opacity = '0';
                setTimeout(() => {
                    if (typingDiv.parentNode) {
                        chatMessages.removeChild(typingDiv);
                    }
                }, 200);
            }
        
            if (data.response) {
                addMessage(data.response);
                saveCurrentChat();
            } else if (data.error) {
                addMessage(`Ошибка: ${data.error}`);
            }
        
            // Clear file input after sending
            if (fileInput.files.length > 0) {
                fileInput.value = '';
                resetAttachButton();
            }
        
        } catch (error) {
            console.error('Ошибка при отправке запроса:', error);
        
            // Remove typing indicator
            if (typingDiv.parentNode) {
                chatMessages.removeChild(typingDiv);
            }
        
            addMessage(`Ошибка: ${error.message}`);
        } finally {
            // Re-enable input
            setInputState(true);
        }
    }
    
    function createTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message assistant typing-message';
        typingDiv.innerHTML = `
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        return typingDiv;
    }
    
    function setInputState(enabled) {
        userInput.disabled = !enabled;
        sendButton.disabled = !enabled;
        attachButton.disabled = !enabled;
        
        if (enabled) {
            userInput.focus();
        }
    }

    
    fileInput.addEventListener('change', function() {
        isFileDialogOpen = false; // Сбрасываем флаг когда файл выбран
    
        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            const fileSize = (fileInput.files[0].size / 1024 / 1024).toFixed(2);
        
            attachButton.innerHTML = `
                <div class="file-info">
                    <span class="file-name">${fileName.length > 15 ? fileName.substring(0, 15) + '...' : fileName}</span>
                    <span class="file-size">${fileSize}MB</span>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            `;
        
            attachButton.classList.add('file-selected');
            attachButton.title = `Файл: ${fileName} (${fileSize}MB) - Нажмите для отмены`;
        }
    });

    function resetAttachButton() {
        attachButton.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21.44 11.05L12.25 20.24C11.1242 21.3658 9.59723 21.9983 8.005 21.9983C6.41277 21.9983 4.88584 21.3658 3.76 20.24C2.63416 19.1142 2.00166 17.5872 2.00166 15.995C2.00166 14.4028 2.63416 12.8758 3.76 11.75L12.33 3.18C13.0806 2.42975 14.0991 2.00129 15.16 2.00129C16.2209 2.00129 17.2394 2.42975 17.99 3.18C18.7403 3.93063 19.1687 4.94905 19.1687 5.995C19.1687 7.04095 18.7403 8.05937 17.99 8.81L9.41 17.39C9.03472 17.7653 8.52573 17.9788 7.995 17.9788C7.46427 17.9788 6.95528 17.7653 6.58 17.39C6.20472 17.0147 5.99122 16.5057 5.99122 15.975C5.99122 15.4443 6.20472 14.9353 6.58 14.56L14.54 6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        `;
        attachButton.classList.remove('file-selected');
        attachButton.title = 'Прикрепить файл';
    }

    // Основной обработчик для кнопки прикрепления
    attachButton.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
    
        if (isFileDialogOpen) {
            return; // Предотвращаем повторное открытие
        }
    
        if (attachButton.classList.contains('file-selected')) {
            // Если файл уже выбран, очищаем его
            fileInput.value = '';
            resetAttachButton();
        } else {
            // Открываем диалог выбора файла
            isFileDialogOpen = true;
            fileInput.click();
        
            // Сбрасываем флаг через небольшую задержку на случай отмены
            setTimeout(() => {
                if (fileInput.files.length === 0) {
                    isFileDialogOpen = false;
                }
            }, 1000);
        }
    });

    // Обработчик для отмены выбора файла (когда пользователь закрывает диалог без выбора)
    fileInput.addEventListener('cancel', function() {
        isFileDialogOpen = false;
    });

    function loadSavedChats() {
        const savedChats = Object.keys(localStorage)
            .filter(key => key.startsWith('chat-'))
            .map(key => {
                try {
                    const data = localStorage.getItem(key);
                    const parsed = JSON.parse(data);
                    
                    // Handle both old and new format
                    if (parsed.createdAt) {
                        return {
                            id: key,
                            title: parsed.title || 'Новый чат',
                            createdAt: parsed.createdAt
                        };
                    } else {
                        // Old format - use key timestamp
                        const timestamp = parseInt(key.replace('chat-', ''));
                        return {
                            id: key,
                            title: 'Новый чат',
                            createdAt: timestamp
                        };
                    }
                } catch (e) {
                    return null;
                }
            })
            .filter(chat => chat !== null)
            .sort((a, b) => b.createdAt - a.createdAt);
        
        if (savedChats.length > 0) {
                        savedChats.forEach(chat => {
                addChatToSidebar(chat.id, chat.title);
            });
            
            // Load the most recent chat
            const mostRecentChat = savedChats[0];
            loadChat(mostRecentChat.id);
            const chatItem = document.querySelector(`[data-id="${mostRecentChat.id}"]`);
            if (chatItem) {
                setActiveChatItem(chatItem);
            }
            currentChatId = mostRecentChat.id;
        } else {
            // No saved chats, create initial chat
            createNewChat();
        }
    }
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Auto-resize textarea
    userInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
      
    // Global function for new chat button
    window.createNewChat = createNewChat;
    
    // Load saved chats on page load
    loadSavedChats();
    
    // Focus input on load
    userInput.focus();
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        saveCurrentChat();
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + N for new chat
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            createNewChat();
        }
        
        // Escape to focus input
        if (e.key === 'Escape' && !isEditingTitle) {
            userInput.focus();
        }
    });
});