import uvicorn
from core.agent import AIAgent
from plugins.example_api import API_model
import threading
import signal
import sys
import time

def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения работы"""
    print('\nПолучен сигнал завершения. Останавливаем сервисы...')
    sys.exit(0)

def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("🚀 Запуск Jane AI Assistant...")
    
    # Инициализация и запуск ИИ-агента
    agent = AIAgent()
    
    try:
        agent.start()
        print("✅ AI Agent запущен")
        
        api_thread = threading.Thread(target=API_model, args=(agent,))
        api_thread.daemon = True
        api_thread.start()
        print("✅ API модель запущена")
        
        time.sleep(2)
        
        print("🌐 Запуск веб-сервера на http://127.0.0.1:8000")
        print("📱 Откройте браузер и перейдите по адресу выше")
        print("⏹️  Для остановки нажмите Ctrl+C")
        
        uvicorn.run(
            "web_server:app", 
            host="127.0.0.1", 
            port=8000, 
            reload=False,
            log_level="info"
        )
        
    except KeyboardInterrupt:
        print("\n⏹️  Получен сигнал остановки...")
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("🔄 Останавливаем AI Agent...")
        agent.stop()
        print("✅ Jane AI Assistant остановлен")

if __name__ == "__main__":
    main()