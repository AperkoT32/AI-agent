document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const fileInput = document.getElementById('file-input');
    const attachButton = document.getElementById('attach-button');
    
    let chatHistory = [];
    let currentChatId = 'chat-' + Date.now();
    
    function createNewChat() {
        // Save current chat if needed
        saveCurrentChat();
        
        // Create new chat ID
        currentChatId = 'chat-' + Date.now();
        
        // Clear messages
        chatMessages.innerHTML = `
            <div class="message assistant">
                <div class="message-content">Привет! Я Джейн, ваш ИИ-ассистент. Чем могу помочь?</div>
            </div>
        `;
        
        // Reset chat history for new chat
        chatHistory = [];
        
        // Add to sidebar (implementation depends on your needs)
        addChatToSidebar(currentChatId, 'Новый чат');
    }
    
    function addChatToSidebar(id, title) {
        const chatHistory = document.querySelector('.chat-history');
        const chatItem = document.createElement('div');
        chatItem.className = 'chat-item';
        chatItem.dataset.id = id;
        chatItem.innerHTML = `
            <span>${title}</span>
            <button class="delete-chat">×</button>
        `;
        chatItem.addEventListener('click', () => loadChat(id));
        chatHistory.appendChild(chatItem);
    }
    
    function saveCurrentChat() {
        // Implementation for saving chat to localStorage or backend
        // This is a placeholder
        const messages = Array.from(chatMessages.children).map(msg => {
            return {
                type: msg.classList.contains('user') ? 'user' : 'assistant',
                content: msg.querySelector('.message-content').textContent
            };
        });
        
        localStorage.setItem(currentChatId, JSON.stringify(messages));
    }
    
    function loadChat(chatId) {
        // Implementation for loading chat from localStorage or backend
        // This is a placeholder
        const savedChat = localStorage.getItem(chatId);
        if (savedChat) {
            const messages = JSON.parse(savedChat);
            chatMessages.innerHTML = '';
            messages.forEach(msg => {
                addMessage(msg.content, msg.type === 'user');
            });
            currentChatId = chatId;
        }
    }

    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.textContent = content;
        
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        // Add to chat history
        chatHistory.push({
            type: isUser ? 'user' : 'assistant',
            content: content
        });
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;
        
        addMessage(message, true);
        userInput.value = '';
        
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message assistant';
        loadingDiv.id = 'loading-message';
        
        const loadingContent = document.createElement('div');
        loadingContent.className = 'message-content';
        loadingContent.textContent = 'Думаю...';
        
        loadingDiv.appendChild(loadingContent);
        chatMessages.appendChild(loadingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        try {
            console.log('Отправка запроса:', message);
            
            // Check if we have an attached file
            let formData = new FormData();
            let hasFile = false;
            
            if (fileInput.files.length > 0) {
                formData.append('file', fileInput.files[0]);
                hasFile = true;
            }
            
            formData.append('message', message);
            
            const response = await fetch('/api/chat', {
                method: 'POST',
                body: hasFile ? formData : JSON.stringify({ message }),
                headers: hasFile ? {} : {
                    'Content-Type': 'application/json',
                },
            });
            
            console.log('Получен ответ:', response);
            const data = await response.json();
            console.log('Данные ответа:', data);
            
            const loadingMessage = document.getElementById('loading-message');
            if (loadingMessage) {
                chatMessages.removeChild(loadingMessage);
            }
                        if (data.response) {
                addMessage(data.response);
                
                // Save chat after each message exchange
                saveCurrentChat();
            } else if (data.error) {
                addMessage(`Ошибка: ${data.error}`);
            }
            
            // Clear file input after sending
            if (fileInput.files.length > 0) {
                fileInput.value = '';
            }
        } catch (error) {
            console.error('Ошибка при отправке запроса:', error);
            
            const loadingMessage = document.getElementById('loading-message');
            if (loadingMessage) {
                chatMessages.removeChild(loadingMessage);
            }
            
            addMessage(`Ошибка: ${error.message}`);
        }
    }

    // Handle file input change to show selected file
    fileInput.addEventListener('change', function() {
        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            attachButton.innerHTML = `
                <span class="file-name">${fileName.length > 10 ? fileName.substring(0, 10) + '...' : fileName}</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            `;
            
            // Add class to show file is selected
            attachButton.classList.add('file-selected');
            
            // Add click handler to clear file
            attachButton.onclick = function(e) {
                e.stopPropagation();
                fileInput.value = '';
                resetAttachButton();
            };
        }
    });
    
    function resetAttachButton() {
        attachButton.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21.44 11.05L12.25 20.24C11.1242 21.3658 9.59723 21.9983 8.005 21.9983C6.41277 21.9983 4.88584 21.3658 3.76 20.24C2.63416 19.1142 2.00166 17.5872 2.00166 15.995C2.00166 14.4028 2.63416 12.8758 3.76 11.75L12.33 3.18C13.0806 2.42975 14.0991 2.00129 15.16 2.00129C16.2209 2.00129 17.2394 2.42975 17.99 3.18C18.7403 3.93063 19.1687 4.94905 19.1687 5.995C19.1687 7.04095 18.7403 8.05937 17.99 8.81L9.41 17.39C9.03472 17.7653 8.52573 17.9788 7.995 17.9788C7.46427 17.9788 6.95528 17.7653 6.58 17.39C6.20472 17.0147 5.99122 16.5057 5.99122 15.975C5.99122 15.4443 6.20472 14.9353 6.58 14.56L14.54 6.6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        `;
        attachButton.classList.remove('file-selected');
        
        // Reset click handler
        attachButton.onclick = function() {
            fileInput.click();
        };
    }

    // Add event listeners
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Initialize the chat interface
    window.createNewChat = createNewChat; // Make it globally available for the button
    
    // Check if there are saved chats
    const savedChats = Object.keys(localStorage).filter(key => key.startsWith('chat-'));
    if (savedChats.length > 0) {
        // Load the most recent chat
        const mostRecentChat = savedChats.sort().pop();
        loadChat(mostRecentChat);
    }
    
    // Add animation effects for smooth transitions
    document.querySelectorAll('.message').forEach(message => {
        message.style.opacity = '0';
        message.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            message.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            message.style.opacity = '1';
            message.style.transform = 'translateY(0)';
        }, 100);
    });
    
    // Focus on input field when page loads
    userInput.focus();
});

// Add additional CSS for file attachment styling
document.head.insertAdjacentHTML('beforeend', `
<style>
.attach-btn.file-selected {
    background-color: #e6f2ff;
    color: #007aff;
    padding: 6px 10px;
    border-radius: 16px;
    width: auto;
    display: flex;
    align-items: center;
    gap: 5px;
}

.file-name {
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Animation for new messages */
.message {
    transition: opacity 0.3s ease, transform 0.3s ease;
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
    body {
        background-color: #1a1a1a;
        color: #f5f5f7;
    }
    
    #sidebar {
        background-color: #252525;
        border-right: 1px solid #333;
    }
    
    .logo h2 {
        color: #f5f5f7;
    }
    
    .chat-input {
        background-color: #252525;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    }
    
    .chat-input input {
        color: #f5f5f7;
    }
    
    .assistant .message-content {
        background-color: #333;
        color: #f5f5f7;
    }
    
    .attach-btn:hover, .send-btn:hover {
        background-color: #333;
    }
    
    .chat-header h1 {
        color: #f5f5f7;
    }
}
</style>
`);