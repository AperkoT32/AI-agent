from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
import socket
import json
from typing import Optional
from plugins.example_api import sanitize_input, get_base64_uri

app = FastAPI()

HOST = '127.0.0.1'
PORT = 5050

@app.get("/")
def root():
    return FileResponse("index.html")

@app.get("/style.css")
def get_style():
    return FileResponse("style.css")

@app.get("/script.js")
def get_script():
    return FileResponse("script.js")

@app.post("/api/chat")
async def chat(
    request: Request,
    message: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None)
):
    try:
        content_type = request.headers.get('content-type', '')

        if 'application/json' in content_type:
            # Существенных изменений нет, обрабатываем JSON как раньше
            data = await request.json()
            user_message = data.get("message")
            if not user_message:
                return JSONResponse(content={"error": "Пустое сообщение"}, status_code=400)

            sanitized_message = sanitize_input(user_message)

            with socket.create_connection((HOST, PORT), timeout=10) as sock:
                sock.sendall(json.dumps({"message": sanitized_message}).encode())
                response_data = sock.recv(4096)
                result = json.loads(response_data.decode())

            if "response" in result:
                return {"response": result["response"]}
            else:
                return JSONResponse(content={"error": result.get("error", "Агент не ответил")}, status_code=500)

        elif 'multipart/form-data' in content_type:
            # Обработка формы с файлом и текстом
            if not message and not image:
                return JSONResponse(content={"error": "Нет данных"}, status_code=400)

            sanitized_message = sanitize_input(message) if message else ""

            payload = {"message": sanitized_message}

            if image:
                # base64-кодируем файл с помощью функции из example_api.py
                base64_image = get_base64_uri(image)
                if not base64_image:
                    return JSONResponse(content={"error": "Ошибка кодирования изображения"}, status_code=500)
                payload["image"] = base64_image

            # Отправляем комбинированный payload агенту через сокет
            with socket.create_connection((HOST, PORT), timeout=10) as sock:
                sock.sendall(json.dumps(payload).encode())
                response_data = sock.recv(4096)
                result = json.loads(response_data.decode())

            if "response" in result:
                return {"response": result["response"]}
            else:
                return JSONResponse(content={"error": result.get("error", "Агент не ответил")}, status_code=500)

        else:
            return JSONResponse(content={"error": f"Неподдерживаемый Content-Type: {content_type}"}, status_code=400)

    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)
