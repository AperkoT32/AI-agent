document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const fileInput = document.getElementById('file-input');
    const sendButton = document.getElementById('send-button');

    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';

        // Добавляем изображение, если content — с картинкой
        if (typeof content === 'object' && content.type === 'image') {
            const img = document.createElement('img');
            img.src = content.dataUrl;
            img.style.maxWidth = "200px";
            messageContent.appendChild(img);
        } else {
            messageContent.textContent = content;
        }
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

 // Находим/создаём место для показа инфы о выбранном файле:
    const chatInputDiv = document.querySelector('.chat-input');
    let fileInfoDiv = document.createElement('div');
    fileInfoDiv.id = 'file-info';
    fileInfoDiv.style.fontSize = "0.9em";
    fileInfoDiv.style.color = "#888";
    chatInputDiv.appendChild(fileInfoDiv);

    // Показываем название файла при выборе
    fileInput.addEventListener('change', function() {
        if (fileInput.files[0]) {
            fileInfoDiv.textContent = 'Выбран файл: ' + fileInput.files[0].name;
        } else {
            fileInfoDiv.textContent = '';
        }
    });

    async function sendMessage() {
        const message = userInput.value.trim();
        const file = fileInput.files[0];
        if (!message && !file) return;

        if (message) addMessage(message, true);
        if (file) addMessage({type: 'image', dataUrl: URL.createObjectURL(file)}, true);

        userInput.value = '';
        fileInput.value = '';

        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message assistant';
        loadingDiv.id = 'loading-message';
        const loadingContent = document.createElement('div');
        loadingContent.className = 'message-content';
        loadingContent.textContent = 'Думаю...';
        loadingDiv.appendChild(loadingContent);
        chatMessages.appendChild(loadingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        let body;
        let headers = {};

        if (file) {
            body = new FormData();
            body.append('message', message);
            body.append('image', file);
            // Content-Type формируется браузером автоматически
        } else {
            body = JSON.stringify({ message });
            headers['Content-Type'] = 'application/json';
        }

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers,
                body,
            });
            const data = await response.json();

            const loadingMessage = document.getElementById('loading-message');
            if (loadingMessage) chatMessages.removeChild(loadingMessage);

            if (data.response) {
                addMessage(data.response);
            } else if (data.error) {
                addMessage(`Ошибка: ${data.error}`);
            }
        } catch (error) {
            const loadingMessage = document.getElementById('loading-message');
            if (loadingMessage) chatMessages.removeChild(loadingMessage);
            addMessage(`Ошибка: ${error.message}`);
        }
        fileInfoDiv.textContent = '';
    }

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') sendMessage();
    });

    // реализовал attachButton/fileInput обработку — ничего менять не надо!
});
